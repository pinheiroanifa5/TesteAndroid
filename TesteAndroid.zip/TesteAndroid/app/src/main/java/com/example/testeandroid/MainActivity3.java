package com.example.testeandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.testeandroid.R;

public class MainActivity3 extends AppCompatActivity {

    Button btnContinuar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnContinuar = findViewById(R.id.btncont);

        btnContinuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirNovaActivity();
            }
        });
    }

    private void abrirNovaActivity() {
        Intent intent = new Intent(MainActivity3.this, MainActivity3.class);
        startActivity(intent);
    }
}
